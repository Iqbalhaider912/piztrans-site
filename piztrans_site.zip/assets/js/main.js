
// Simple i18n loader
const LANGS = ['en','ar','es'];
let currentLang = localStorage.getItem('lang') || 'en';
document.addEventListener('DOMContentLoaded', async () => {
  await setLanguage(currentLang);
  const langSelect = document.querySelector('#langSelect');
  if (langSelect){
    langSelect.value = currentLang;
    langSelect.addEventListener('change', async (e)=>{
      const lang = e.target.value;
      await setLanguage(lang);
    });
  }

  // Populate selects if present
  await prepareDatasets();
  bindQuoteForm();
  renderWeeklyQuotes();
});

async function setLanguage(lang){
  if(!LANGS.includes(lang)) lang = 'en';
  currentLang = lang;
  localStorage.setItem('lang', lang);
  const dir = (lang==='ar') ? 'rtl' : 'ltr';
  document.documentElement.setAttribute('dir', dir);

  try{
    const res = await fetch(`/i18n/${lang}.json`);
    const dict = await res.json();
    document.querySelectorAll('[data-i18n]').forEach(el=>{
      const key = el.getAttribute('data-i18n');
      if (dict[key]) el.textContent = dict[key];
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
      const key = el.getAttribute('data-i18n-placeholder');
      if (dict[key]) el.setAttribute('placeholder', dict[key]);
    });
  }catch(e){
    console.warn('i18n load failed', e);
  }
}

// Data preparation and admin CSV uploads
async function prepareDatasets(){
  // Load defaults
  const defaults = {
    countries: await fetch('/data/countries.json').then(r=>r.json()).catch(()=>[]),
    ports: await fetch('/data/ports.sample.json').then(r=>r.json()).catch(()=>({})) // { "Country": ["Port A","Port B"] }
  };
  // Check overrides in localStorage (uploaded via admin)
  const countriesLS = localStorage.getItem('countries.json');
  const portsLS = localStorage.getItem('ports.json');
  window.COUNTRIES = countriesLS ? JSON.parse(countriesLS) : defaults.countries;
  window.PORTS = portsLS ? JSON.parse(portsLS) : defaults.ports;
}

// Bind quote form
function bindQuoteForm(){
  const form = document.getElementById('rfqForm');
  if(!form) return;

  const polCountry = form.querySelector('#polCountry');
  const podCountry = form.querySelector('#podCountry');
  const polPort = form.querySelector('#polPort');
  const podPort = form.querySelector('#podPort');

  // Populate country dropdowns
  [polCountry, podCountry].forEach(sel=>{
    if(!sel) return;
    sel.innerHTML = '<option value="">— Select —</option>' + (window.COUNTRIES||[]).map(c=>`<option value="${c}">${c}</option>`).join('');
    sel.addEventListener('change', e=>{
      const which = e.target.id === 'polCountry' ? polPort : podPort;
      const country = e.target.value;
      const ports = (window.PORTS && window.PORTS[country]) || [];
      if(which){
        which.innerHTML = '<option value="">— Select —</option>' + ports.map(p=>`<option value="${p}">${p}</option>`).join('');
      }
    });
  });

  // Populate shipment mode
  const mode = form.querySelector('#mode');
  if(mode){
    ['Land','Air','Sea'].forEach(m=>{
      const opt=document.createElement('option'); opt.value=m.toLowerCase(); opt.textContent=m;
      mode.appendChild(opt);
    });
  }

  // Submit handler (no captcha)
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());

    // Simple validation
    const required = ['name','phone','email','polCountry','polPort','podCountry','podPort','mode'];
    const missing = required.filter(k=>!data[k] || String(data[k]).trim()==='');
    if(missing.length){
      alert('Please complete required fields: ' + missing.join(', '));
      return;
    }
    // Save to localStorage as demo submission log
    const log = JSON.parse(localStorage.getItem('rfq_submissions')||'[]');
    log.push({...data, ts:new Date().toISOString()});
    localStorage.setItem('rfq_submissions', JSON.stringify(log));
    form.reset();
    alert('Your request for quotation has been recorded. Our team will contact you at info@piztrans.com.');
  });
}

// Render weekly quotes on quotes.html
function renderWeeklyQuotes(){
  const table = document.getElementById('weeklyQuotesTable');
  if(!table) return;
  const raw = localStorage.getItem('weekly_quotes');
  let rows = [];
  try{ rows = JSON.parse(raw)||[] }catch{ rows = [] }
  const tbody = table.querySelector('tbody');
  tbody.innerHTML = '';
  if(!rows.length){
    const tr = document.createElement('tr');
    const td = document.createElement('td'); td.colSpan = 7; td.textContent='No quotes uploaded yet.';
    tr.appendChild(td); tbody.appendChild(tr); return;
  }
  rows.forEach(r=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.week||''}</td><td>${r.mode||''}</td><td>${r.origin||''}</td><td>${r.destination||''}</td><td>${r.commodity||''}</td><td>${r.rate||''}</td><td>${r.notes||''}</td>`;
    tbody.appendChild(tr);
  });
}

// Admin CSV uploads for countries, ports, weekly quotes
window.Admin = {
  uploadCSV: async function(file, type){
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter(Boolean);
    if(type==='countries'){
      // One country per line
      const countries = lines.map(s=>s.trim()).filter(Boolean);
      localStorage.setItem('countries.json', JSON.stringify(countries));
      alert('Countries updated: '+countries.length);
    } else if(type==='ports'){
      // Expect columns: country,port
      const map = {};
      lines.slice(1).forEach(line=>{
        const parts = line.split(','); if(parts.length<2) return;
        const country = parts[0].trim(); const port = parts[1].trim();
        if(!map[country]) map[country]=[];
        if(!map[country].includes(port)) map[country].push(port);
      });
      localStorage.setItem('ports.json', JSON.stringify(map));
      alert('Ports updated for '+Object.keys(map).length+' countries.');
    } else if(type==='weekly_quotes'){
      // Expect columns: week,mode,origin,destination,commodity,rate,notes
      const out = [];
      const headers = lines[0].split(',').map(h=>h.trim().toLowerCase());
      const idx = (k)=> headers.indexOf(k);
      for(let i=1;i<lines.length;i++){
        const cells = lines[i].split(',');
        out.push({
          week: cells[idx('week')]||'',
          mode: cells[idx('mode')]||'',
          origin: cells[idx('origin')]||'',
          destination: cells[idx('destination')]||'',
          commodity: cells[idx('commodity')]||'',
          rate: cells[idx('rate')]||'',
          notes: cells[idx('notes')]||''
        });
      }
      localStorage.setItem('weekly_quotes', JSON.stringify(out));
      alert('Weekly quotes uploaded: '+out.length);
    }
  }
};
